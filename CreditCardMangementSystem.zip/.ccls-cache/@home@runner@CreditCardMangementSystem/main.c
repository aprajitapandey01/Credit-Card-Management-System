#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure to represent a credit card
struct CreditCard {
    char cardNumber[17];
    char cardHolderName[50];
    double balance;
};

// Structure to represent a transaction
struct Transaction {
    char cardNumber[17];
    double amount;
    char description[100];
};

// Function to issue a new unique credit card number
void issueCreditCard(struct CreditCard *cards, int *numCards) {
    if (*numCards >= 100) {
        printf("Maximum number of cards issued.\n");
        return;
    }

    // Generate a unique card number (simplified example)
    sprintf(cards[*numCards].cardNumber, "4%d", *numCards);

    printf("Enter card holder's name: ");
    scanf(" %[^\n]", cards[*numCards].cardHolderName);

    cards[*numCards].balance = 0.0;

    (*numCards)++;
    printf("Credit card issued successfully.\n");
}

// Function to process a payment
void processPayment(struct CreditCard *cards, int numCards, struct Transaction *transactions, int *numTransactions) {
    char cardNumber[17];
    double amount;
    printf("Enter card number: ");
    scanf("%s", cardNumber);

    int cardIndex = -1;
    for (int i = 0; i < numCards; i++) {
        if (strcmp(cards[i].cardNumber, cardNumber) == 0) {
            cardIndex = i;
            break;
        }
    }

    if (cardIndex == -1) {
        printf("Card not found.\n");
        return;
    }

    printf("Enter payment amount: ");
    scanf("%lf", &amount);

    if (amount <= 0) {
        printf("Invalid payment amount.\n");
        return;
    }

    cards[cardIndex].balance -= amount;

    // Record transaction
    strcpy(transactions[*numTransactions].cardNumber, cardNumber);
    transactions[*numTransactions].amount = -amount;
    strcpy(transactions[*numTransactions].description, "Payment");
    (*numTransactions)++;

    printf("Payment processed successfully.\n");
}

// Function to display transaction history
void displayTransactionHistory(struct Transaction *transactions, int numTransactions) {
    printf("Transaction History:\n");
    for (int i = 0; i < numTransactions; i++) {
        printf("Transaction %d:\n", i + 1);
        printf("  Card Number: %s\n", transactions[i].cardNumber);
        printf("  Amount: %.2f\n", transactions[i].amount);
        printf("  Description: %s\n", transactions[i].description);
    }
}

int main() {
    struct CreditCard creditCards[100];
    struct Transaction transactions[1000];
    int numCreditCards = 0;
    int numTransactions = 0;
    int choice;

    while (1) {
        printf("\nCredit Card Management System\n");
        printf("1. Issue Credit Card\n");
        printf("2. Process Payment\n");
        printf("3. Transaction History\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                issueCreditCard(creditCards, &numCreditCards);
                break;
            case 2:
                processPayment(creditCards, numCreditCards, transactions, &numTransactions);
                break;
            case 3:
                displayTransactionHistory(transactions, numTransactions);
                break;
            case 4:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice. Please select a valid option.\n");
        }
    }

    return 0;
}
